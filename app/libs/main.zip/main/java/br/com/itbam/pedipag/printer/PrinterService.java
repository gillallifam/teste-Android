package br.com.itbam.pedipag.printer;

import android.graphics.Bitmap;
import android.util.Log;

import com.pax.dal.entity.EFontTypeAscii;
import com.pax.dal.entity.EFontTypeExtCode;

public class PrinterService
{

    public void PrintBitmap(final Bitmap bitmap)
    {
        new Thread(new Runnable() {
            public void run() {
                PrinterTester.getInstance().init();
                PrinterTester.getInstance().fontSet(EFontTypeAscii.FONT_8_16, EFontTypeExtCode.FONT_16_16);

                PrinterTester.getInstance().spaceSet(Byte.parseByte("0"), Byte.parseByte("0"));
                PrinterTester.getInstance().leftIndents(Short.parseShort("0"));
                PrinterTester.getInstance().setGray(Integer.parseInt("1"));
                PrinterTester.getInstance().setDoubleWidth(false, false);
                PrinterTester.getInstance().setDoubleHeight(false, false);
                PrinterTester.getInstance().setInvert(false);

                PrinterTester.getInstance().printBitmap(bitmap);
                final String status = PrinterTester.getInstance().start();
                Log.e("PRINT_STATUS", status);

                PrinterTester.getInstance().cutPaper(0);

            }
        }).start();
    }


    public  void Print(final String srt)
    {

        new Thread(new Runnable() {
            public void run() {
                PrinterTester.getInstance().init();
                PrinterTester.getInstance().fontSet(EFontTypeAscii.FONT_8_16,
                        EFontTypeExtCode.FONT_16_16);

                PrinterTester.getInstance().spaceSet(Byte.parseByte("0"), Byte.parseByte("0"));
                PrinterTester.getInstance().leftIndents(Short.parseShort("0"));
                PrinterTester.getInstance().setGray(Integer.parseInt("1"));
                PrinterTester.getInstance().setDoubleWidth(false, false);
                PrinterTester.getInstance().setDoubleHeight(false, false);

                PrinterTester.getInstance().setInvert(false);

                if (srt != null && srt.length() > 0)
                    PrinterTester.getInstance().printStr(srt, null);
                PrinterTester.getInstance().step(Integer.parseInt("150"));
                final String status = PrinterTester.getInstance().start();
                Log.e("PRINT_STATUS", status);

                PrinterTester.getInstance().cutPaper(0);

            }
        }).start();

    }
}
