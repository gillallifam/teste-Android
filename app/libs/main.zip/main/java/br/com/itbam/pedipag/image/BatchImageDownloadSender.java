package br.com.itbam.pedipag.image;

import android.content.Context;

public class BatchImageDownloadSender
{
    public int mId;
    public String mURL;
    public IImageDownloadReceiver mReceiver;
    public Context mContext;
    public ImageDowloadService.DownloadType mType;

    public BatchImageDownloadSender(Context c, int id, IImageDownloadReceiver mReceiver, String mURL, ImageDowloadService.DownloadType t)
    {
        this.mContext = c;
        this.mId = id;
        this.mURL = mURL;
        this.mReceiver = mReceiver;
        this.mType = t;
    }
}
