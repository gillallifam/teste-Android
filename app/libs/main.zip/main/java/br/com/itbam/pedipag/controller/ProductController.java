package br.com.itbam.pedipag.controller;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import br.com.itbam.pedipag.R;
import br.com.itbam.pedipag.image.ImageDowloadService;
import br.com.itbam.pedipag.model.Cart;
import br.com.itbam.pedipag.model.Group;
import br.com.itbam.pedipag.model.ItemVenda;
import br.com.itbam.pedipag.model.Product;
import br.com.itbam.pedipag.model.Segment;
import br.com.itbam.pedipag.view.MainActivity;

public class ProductController implements MainRecyclerViewAdapter.ItemClickListener {

    private LinearLayout LLCategories;
    private LinearLayout LLSubCategories;
    private RecyclerView mainRecyclerView;
    private Context mainContext;
    private Cart cart;
    private LinearLayout cartView;
    private RequestQueue queueData;
    private ArrayList<Segment> segments;
    private HashMap<String, ArrayList<Group>> groups;
    private HashMap<String, ArrayList<Product>> productsInGroup;
    private ArrayList<Product> allProducts;
    private ArrayList<Product> showingProducts;
    private int requestGroupCounter = 0;
    private int requestProductCounter = 0;
    private String portPayment = "8000";
    private String serverPayment = "172.100.11.131:" + portPayment;
    private DefaultRetryPolicy retryPolicy;
    private MainRecyclerViewAdapter adapter;
    final MediaPlayer mp;

    private ImageDowloadService mImageService;


    public static final int PORT_DATA = 7200;
    public static final String SERVER_DATA = "172.100.10.101";
    public static final String SERVER_PORT_DATA = SERVER_DATA + ":" + PORT_DATA;
    public static final String NFCe_SERVER_URL = SERVER_PORT_DATA + "/nfce/download-img";
    public static final String PRODUCT_IMAGE_SERVER_URL = SERVER_PORT_DATA + "/downloadFile/";


    public ProductController(Context context) {
        Activity act = (Activity) context;
        this.mainRecyclerView = act.findViewById(R.id.mainRecyclerView);
        this.LLCategories = act.findViewById(R.id.LLListaDeTiposDeProdutos);
        this.LLCategories = act.findViewById(R.id.LLListaDeTiposDeProdutos);
        this.LLSubCategories = act.findViewById(R.id.LLSubCategories);
        this.mainContext = context;
        this.cart = new Cart(context);
        this.cartView = act.findViewById(R.id.LLItensInCart);
        this.queueData = Volley.newRequestQueue(context);
        this.segments = new ArrayList<>();
        this.groups = new HashMap<>();
        this.productsInGroup = new HashMap<>();
        this.allProducts = new ArrayList<>();
        this.showingProducts = new ArrayList<>();
        this.mainRecyclerView.setLayoutManager(new GridLayoutManager(context, 3));
        adapter = new MainRecyclerViewAdapter(context, showingProducts);
        adapter.setClickListener(this);
        this.mainRecyclerView.setAdapter(adapter);
        this.mp = MediaPlayer.create(mainContext, R.raw.select5);
        this.mImageService = new ImageDowloadService(context);

    }

    @Override
    public void onItemClick(View view, int position) {
        ImageView imgv = view.findViewById(R.id.imgMainItem);
        //mp.reset();
        mp.start();
        mp.seekTo(0);

        ObjectAnimator
                .ofFloat(imgv, "scaleY", 0.5f, 0.75f, 1.0f, 1.5f, 1.0f)
                .setDuration(300)
                .start();
        Product product = showingProducts.get(position);
        if (product.getQuantity() > getCart().getProductQuantity(product.getId())) {
            if (cart.getCartProductById(product.getId()).getId() == 0) {
                String imagePath = product.getLocalImagePath();
                cart.addProductItem(new ItemVenda(product.getId(), product.getName(), product.getPrice(), imagePath));
                LinearLayout cartProductLayout = createCartProductItem(product, (ImageView) view.findViewById(R.id.imgMainItem));
                cartView.addView(cartProductLayout, 0);
            } else {
                cart.incrementCartProductQuantity(product.getId());
                ItemVenda cartProduct = cart.getCartProductById(product.getId());
                TextView productQuantityTextView = cartView.findViewWithTag("cart_product_quantity_" + product.getId());
                productQuantityTextView.setText(cartProduct.getQuantity() + "");
            }
            cart.sumTotal(product.getPrice());
        } else {
            System.out.println("esgotado");
        }
    }

    public Cart getCart() {
        return cart;
    }

    public void init(String msg) {
        retryPolicy = new DefaultRetryPolicy(
                30000, 5, 2f);
        ((Activity) mainContext).getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        System.out.println(msg);
        requestGroupCounter = 0;
        requestProductCounter = 0;
        requestSegments();
    }

    private void cancelAllRequests() {
        System.out.println("Cancelling requests.");
        this.queueData.cancelAll("initRequest");
        init("Reiniciando requests");
    }

    private void showSegments() {
        LLCategories.removeAllViews();
        LinearLayout.LayoutParams categoryBtnParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        categoryBtnParams.setMargins(20, 17, 20, 10);
        for (final Segment seg : segments) {
            Button bt = new Button(mainContext);
            bt.setText(seg.getName());
            bt.setTextColor(Color.WHITE);
            bt.setPadding(20, 8, 20, 10);
            bt.setBackground(mainContext.getDrawable(R.drawable.buttonmenu));
            bt.setTextColor(Color.parseColor("#D53850"));
            bt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            bt.setWidth(200);
            bt.setLayoutParams(categoryBtnParams);
            LLCategories.addView(bt);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    LUtil.highlightViewInLayout(view, LLCategories);
                    System.out.println(seg.getName());
                    showGroups(seg.getName());
                    if (LLSubCategories.getChildCount() > 0)
                        LLSubCategories.getChildAt(0).callOnClick();
                }
            });
        }
    }

    private void showGroups(final String segment) {
        LLSubCategories.removeAllViews();
        LinearLayout.LayoutParams subcategoryBtnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        subcategoryBtnParams.setMargins(20, 25, 0, 50);
        for (final Group grp : groups.get(segment)) {
            Button bt = new Button(mainContext);
            bt.setText(grp.getName());
            bt.setPadding(20, 26, 20, 26);
            bt.setWidth(400);
            bt.setBackground(mainContext.getDrawable(R.drawable.buttonmenu));
            bt.setTextColor(Color.parseColor("#D53850"));
            bt.setLayoutParams(subcategoryBtnParams);
            bt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            LLSubCategories.addView(bt);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    LUtil.highlightViewInLayout(view, LLSubCategories);
                    System.out.println(segment + ":" + grp.getName());
                    showingProducts.clear();
                    for (Product prod : allProducts) {
                        if (prod.getCategory().equals(segment) && prod.getSubCategory().equals(grp.getName())) {
                            showingProducts.add(prod);
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            });
        }
    }

    //CREATE CART PRODUCT CONTAINER - START
    private LinearLayout createCartProductItem(Product product, ImageView img) {
        LinearLayout cartProductLayout = this.getCartProductLayout();
        LinearLayout cartProductLeftSide = this.getCartProductLeftSide(product.getName(), product.getPrice(), img);
        LinearLayout cartProductRightSide = this.getCartProductRightSide(1, product.getId());

        cartProductLayout.addView(cartProductRightSide);
        cartProductLayout.addView(cartProductLeftSide, 0);

        cartProductLayout.setTag("cart_product_" + product.getId());

        return cartProductLayout;
    }

    public void clearCart() {
        this.cart.clear();
    }

    public void saveCart() {
        this.cart.saveCartToPrefs();
    }


    private LinearLayout getCartProductLayout() {
        LinearLayout.LayoutParams productContainerParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);

        LinearLayout productContainer = new LinearLayout(mainContext);
        productContainer.setOrientation(LinearLayout.HORIZONTAL);
        productContainer.setLayoutParams(productContainerParams);

        return productContainer;
    }

    //CREATE CART PRODUCT CONTAINER  RIGHT SIDE - START
    private LinearLayout getCartProductRightSide(final int quantity, final int productId) {
        LinearLayout.LayoutParams paramsImgBt = new LinearLayout.LayoutParams(55, 55);
        LinearLayout.LayoutParams rightSideParams = new LinearLayout.LayoutParams(60, ViewGroup.LayoutParams.MATCH_PARENT, 1);
        rightSideParams.setMargins(0, 0, 25, 0);

        LinearLayout rightSideContainer = new LinearLayout(mainContext);
        rightSideContainer.setOrientation(LinearLayout.VERTICAL);
        rightSideContainer.setLayoutParams(rightSideParams);

        ImageView plusButton = new ImageView(mainContext);

        plusButton.setMaxWidth(10);
        plusButton.setImageResource(R.drawable.plus_bt);
        plusButton.setBackgroundColor(Color.TRANSPARENT);
        plusButton.setLayoutParams(paramsImgBt);
        plusButton.setTag("plus_btn_" + productId);

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout cartProductView = (LinearLayout) view.getParent().getParent();
                cart.incrementCartProductQuantity(productId);
                ItemVenda cartProduct = cart.getCartProductById(productId);
                TextView productQuantityTextView = cartProductView.findViewWithTag("cart_product_quantity_" + productId);
                productQuantityTextView.setText(cartProduct.getQuantity() + "");
                cart.sumTotal(cartProduct.getPrice());
            }
        });

        TextView quantityLabel = new TextView(mainContext);
        quantityLabel.setWidth(10);
        quantityLabel.setPadding(10, 0, 0, 0);
        quantityLabel.setTag("cart_product_quantity_" + productId);
        quantityLabel.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        quantityLabel.setGravity(Gravity.CENTER_VERTICAL);
        quantityLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f);
        quantityLabel.setText(quantity + "");

        LinearLayout.LayoutParams quantityParams = new LinearLayout.LayoutParams(150, ViewGroup.LayoutParams.MATCH_PARENT, 2);
        quantityLabel.setLayoutParams(quantityParams);
        quantityLabel.setTextColor(Color.parseColor("#707070"));

        ImageView minusButton = new ImageView(mainContext);
        minusButton.setImageResource(R.drawable.minus_bt);
        minusButton.setBackgroundColor(Color.TRANSPARENT);
        minusButton.setLayoutParams(paramsImgBt);
        minusButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                LinearLayout cartProductView = (LinearLayout) view.getParent().getParent();
                ItemVenda cartProduct = cart.getCartProductById(productId);

                int hasOnlyOne = cart.decrementCartProductQuantity(productId);
                if (hasOnlyOne == 1) {
                    cartProductView.removeAllViews();
                    cart.removeCartProduct(cartProduct);
                } else {
                    TextView productQuantityTextView = cartProductView.findViewWithTag("cart_product_quantity_" + productId);
                    productQuantityTextView.setText(cartProduct.getQuantity() + "");
                }

                cart.sumTotal(cartProduct.getPrice() * -1.0);
            }
        });

        rightSideContainer.addView(plusButton);
        rightSideContainer.addView(quantityLabel);
        rightSideContainer.addView(minusButton);
        return rightSideContainer;
    }


    //CREATE CART PRODUCT CONTAINER  LEFT SIDE - START
    private LinearLayout getCartProductLeftSide(String productName, double productPrice, ImageView img) {
        LinearLayout.LayoutParams leftSideParams = new LinearLayout.LayoutParams(130, ViewGroup.LayoutParams.MATCH_PARENT);

        LinearLayout leftSideContainer = new LinearLayout(mainContext);
        leftSideContainer.setOrientation(LinearLayout.VERTICAL);
        leftSideContainer.setLayoutParams(leftSideParams);

        //product image
        ImageView productImageView = new ImageView(mainContext);
        productImageView.setMaxHeight(165);
        productImageView.setAdjustViewBounds(true);

        try {
            productImageView.setImageBitmap(((BitmapDrawable) img.getDrawable()).getBitmap());
        } catch (Exception err) {
            System.out.println(err);
        }

        //product name label
        TextView productNameTextView = new TextView(mainContext);
        productNameTextView.setText(productName);
        productNameTextView.setPadding(0, 6, 0, 0);
        productNameTextView.setTextColor(Color.parseColor("#707070"));
        productNameTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        productNameTextView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        //product price label
        TextView productPriceTextView = new TextView(mainContext);
        productPriceTextView.setText(NumberFormat.getCurrencyInstance().format(productPrice));
        productPriceTextView.setTextColor(Color.parseColor("#707070"));
        productPriceTextView.setTypeface(Typeface.DEFAULT_BOLD);
        productPriceTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        productPriceTextView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        leftSideContainer.addView(productImageView);
        leftSideContainer.addView(productNameTextView);
        leftSideContainer.addView(productPriceTextView);

        return leftSideContainer;
    }//CREATE CART PRODUCT CONTAINER - END

    //Busca todos os segmentos no banco
    private void requestSegments() {
        String url = "http://" + SERVER_PORT_DATA + "/category";
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject p = response.getJSONObject(i);
                                segments.add(new Segment(p.getString("id"), p.getString("description").toUpperCase()));//adiciona o segmento na lista de segmentos
                            } catch (JSONException e) {
                                System.out.println(e);
                            }
                        }
                        showSegments();//mostra os segmentos na barra de segmentos
                        for (Segment seg : segments) {//para cada segmento busca os grupos
                            requestGroups(seg);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        cancelAllRequests();
                    }
                }
        );
        request.setRetryPolicy(retryPolicy);
        request.setTag("initRequest");
        queueData.add(request);
    }

    //Busca os grupos de um segmento
    private void requestGroups(Segment seg) {
        for (final Segment s : segments) {//arrumar
            if (s.getId().equals(seg.getId())) {
                String url = "http://" + SERVER_PORT_DATA + "/subcategory/category/" + s.getId();
                requestGroupCounter++;

                JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                ArrayList<Group> list = new ArrayList<>();
                                for (int i = 0; i < response.length(); i++) {
                                    try {
                                        JSONObject g = response.getJSONObject(i);
                                        list.add(new Group(g.getString("id"), g.getString("description").toUpperCase()));//adiciona no hashmap
                                    } catch (JSONException e) {
                                        System.out.println(e);
                                    }
                                }
                                requestGroupCounter--;
                                groups.put(s.getName(), list);
                                if (requestGroupCounter == 0) {
                                    requestProducts();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                cancelAllRequests();
                            }
                        }
                );
                request.setRetryPolicy(retryPolicy);
                request.setTag("initRequest");
                queueData.add(request);
            }
        }
    }

    //Busca os produtos do grupo
    private void requestProducts() {
        Iterator it = groups.entrySet().iterator();
        while (it.hasNext()) {
            final HashMap.Entry pair = (HashMap.Entry) it.next();
            for (final Group grp : ((ArrayList<Group>) pair.getValue())) {
                String url = "http://" + SERVER_PORT_DATA + "/product/subcategory/" + grp.getId();
                requestProductCounter++;
                JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                ArrayList<Product> list = new ArrayList<>();
                                for (int i = 0; i < response.length(); i++) {
                                    try {
                                        JSONObject g = response.getJSONObject(i);
                                        Product np = new Product(g.getInt("id"), g.getString("name"), ((String) pair.getKey()).toUpperCase(), grp.getName().toUpperCase(),
                                                g.getDouble("price"), g.getInt("quantity"), g.getString("fileName"));
                                        list.add(np);
                                        allProducts.add(np);
                                    } catch (JSONException e) {
                                        System.out.println(e);
                                    }
                                }
                                requestProductCounter--;
                                productsInGroup.put(pair.getKey() + ":" + grp.getName(), list);//adiciona a lista na chave segment:group > lista de produtos
                                if (requestProductCounter == 0) {
                                    System.out.println("Produtos carregados");
                                    ((Activity) mainContext).getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                    ((MainActivity) mainContext).dismissInitModal();
                                    LLCategories.getChildAt(0).callOnClick();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                cancelAllRequests();
                            }
                        }
                );
                request.setRetryPolicy(retryPolicy);
                request.setTag("initRequest");
                queueData.add(request);
            }
        }
    }

    public void requestPayment(String pass) {
        String url = "http://" + serverPayment + "/api/v1/transaction2/";
        if (pass.equals("258")) {
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            if (response.equals("\"Pagamento efetuado\"")) {
                                ((MainActivity) mainContext).pagamentoEfetuado();
                            } else {
                                ((MainActivity) mainContext).pagamentoRecusado();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                }
            });
            queueData.add(stringRequest);
        } else {
            ((MainActivity) mainContext).pagamentoRecusado();
        }
    }
}
 