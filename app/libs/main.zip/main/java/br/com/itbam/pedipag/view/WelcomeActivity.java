package br.com.itbam.pedipag.view;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import br.com.itbam.pedipag.R;
import br.com.itbam.pedipag.controller.LUtil;

public class WelcomeActivity extends AppCompatActivity {

    public static boolean retornando_do_splash = false;
    public static boolean active = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        final ImageView imageView = findViewById(R.id.welcome_Ok);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                active = false;
                finish();
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                retornando_do_splash = true;
            }
        });
    }

    @Override
    public void onUserInteraction() {
        LUtil.timeCounter = 0;
    }

}