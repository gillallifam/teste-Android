package br.com.itbam.pedipag.image;

import android.graphics.Bitmap;

public class BatchImageDownloadReceiver
{
    public int mId;
    public Bitmap mBitmap;
    public String mFullPath;

    public BatchImageDownloadReceiver(int mId, Bitmap mBitmap, String path) {
        this.mId = mId;
        this.mBitmap = mBitmap;
        this.mFullPath = path;
    }
}
