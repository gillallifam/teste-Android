package br.com.itbam.pedipag.model;

public class ItemVenda {

    private int id;
    private double price;
    private int quantity;
    private String name;
    private String imagePath;

    public ItemVenda(int id, String name, double price, String image) {
        this.id = id;
        this.price = price;
        this.name = name;
        this.quantity = 1;
    }

    public ItemVenda(){}

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int increment() {
        this.quantity++;
        return this.quantity;
    }
    public int decrement() {
        this.quantity--;
        return this.quantity;
    }
}
