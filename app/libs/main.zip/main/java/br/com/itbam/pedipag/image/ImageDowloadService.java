package br.com.itbam.pedipag.image;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class ImageDowloadService {

    public enum DownloadType
    {
        Product,
        Other
    }


    private static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 123;
    private Context mContext;
    private IImageDownloadReceiver mRececiver;

    private ImageDowloadService() {
    }

    public ImageDowloadService(Context context) {
        mContext = context;
    }

    public ImageDowloadService setOnDownloadCompleted(IImageDownloadReceiver receiver) {
        mRececiver = receiver;
        return this;
    }

    public void StartDownload(DownloadType  type, String url, int id) {
        //System.out.println("##############$" + url);
        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions((Activity) mContext, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            ActivityCompat.requestPermissions((Activity) mContext, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            Toast.makeText(mContext, "You need Permission to access storage for Downloading Image", Toast.LENGTH_LONG).show();

        } else if (mRececiver != null)
        {
            new ImageDownloadTask().execute(new BatchImageDownloadSender(mContext, id, mRececiver, url, type));
        }

    }


}
