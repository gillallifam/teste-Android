package br.com.itbam.pedipag.view;


import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;

import com.pax.dal.IDAL;
import com.pax.neptunelite.api.NeptuneLiteUser;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import br.com.itbam.pedipag.R;
import br.com.itbam.pedipag.controller.LUtil;
import br.com.itbam.pedipag.controller.ProductController;
import br.com.itbam.pedipag.model.Cart;
import br.com.itbam.pedipag.model.ItemVenda;

import static android.widget.Toast.LENGTH_LONG;
import static android.widget.Toast.makeText;

public class MainActivity extends AppCompatActivity {

    private TextView txtData;
    private Button btPagar;
    private Button btCancelar;
    private Button btResumoConfirmar;
    private Button btDismissCancelSale;
    private Button btConfirmCancelSale;
    private Button btDismissPaymentSale;
    private Button btDismissResumoSale;
    private Button btConfirmResumoSale;
    private Dialog paymenttWaysSaleDialog;
    private Dialog noItemsInCart;
    private Dialog cancelSaleDialog;
    private Dialog initModal;
    private Dialog noNetModal;
    private Dialog removeCard;
    private Dialog send_email;
    private Dialog thanks;
    private Dialog insertCDS;
    private ProductController prod_Controller;
    private String paymentType = "crédito";
    private String sendType = "imprimir";
    LayoutInflater mInflater;
    private LinearLayout LLCategories;
    public static IDAL idal = null;
    private int timeCounter = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        prod_Controller = new ProductController(this);

        this.activatePaymentDialog();
        this.activateCancelDialog();
        this.activateResumoDialog();
        LUtil.activateTimer((TextView) findViewById(R.id.txtData));

        this.LLCategories = findViewById(R.id.LLListaDeTiposDeProdutos);

        noNetModal = new Dialog(this);
        noNetModal.setCanceledOnTouchOutside(false);
        noNetModal.setContentView(R.layout.no_internet);

        initModal = new Dialog(this);
        initModal.setCanceledOnTouchOutside(false);
        initModal.setContentView(R.layout.init_modal);

        cancelSaleDialog = new Dialog(MainActivity.this);
        cancelSaleDialog.setContentView(R.layout.give_up);
        noItemsInCart = new Dialog(MainActivity.this);
        noItemsInCart.setContentView(R.layout.add_to_cart);
        noItemsInCart.setCancelable(false);
        Button btCloseCartEmpty = noItemsInCart.findViewById(R.id.close_cart_empty_warning);
        btCloseCartEmpty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noItemsInCart.dismiss();
            }
        });

        insertCDS = new Dialog(MainActivity.this);
        insertCDS.setContentView(R.layout.insert_security_code);
        insertCDS.setCancelable(false);

        send_email = new Dialog(MainActivity.this);
        send_email.setContentView(R.layout.send_email);
        send_email.setCancelable(false);

        thanks = new Dialog(MainActivity.this);
        thanks.setContentView(R.layout.thanks);
        thanks.setCancelable(false);

        LUtil.setContext(this);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            idal = NeptuneLiteUser.getInstance().getDal(getApplicationContext());
        } catch (Exception e) {
            e.printStackTrace();
        }

        LUtil.setContext(this);
        LUtil.createProjectFolder();
        noNetModal.show();
        LUtil.checkConnection(ProductController.SERVER_DATA, ProductController.PORT_DATA);
    }

    public void showScreenSaver() {
        if (WelcomeActivity.active == false) {
            Intent i = new Intent(MainActivity.this, WelcomeActivity.class);
            startActivity(i);
            overridePendingTransition(R.anim.slide_up, R.anim.no_change);
            WelcomeActivity.active = true;
        }
    }

    @Override
    public void onUserInteraction() {
        LUtil.timeCounter = 0;
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!WelcomeActivity.retornando_do_splash) {
            //screen welcome
            Intent i = new Intent(this, WelcomeActivity.class);
            startActivity(i);
            overridePendingTransition(R.anim.slide_up, R.anim.no_change);
            WelcomeActivity.active = true;
        }
    }

    public void dismissInitModal() {
        initModal.dismiss();
    }

    public void init() {//Only start after check connection with server
        noNetModal.dismiss();
        initModal.show();
        prod_Controller.init("Iniciando sistema.");
    }

    //Selecionar forma de pagamento
    public void activatePaymentDialog() {
        btPagar = findViewById(R.id.btPagar);

        paymenttWaysSaleDialog = new Dialog(MainActivity.this);
        paymenttWaysSaleDialog.setContentView(R.layout.pagamento);
        paymenttWaysSaleDialog.setCancelable(false);
        paymenttWaysSaleDialog.findViewById(R.id.paymentCredit).setBackground(getDrawable(R.drawable.selected_payment_way));

        btPagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!prod_Controller.getCart().getItens().isEmpty()) {
                    paymenttWaysSaleDialog.show();
                } else {
                    noItemsInCart.show();
                }
            }
        });
        btDismissPaymentSale = paymenttWaysSaleDialog.findViewById(R.id.pm_cancel_payment_bt);
        btDismissPaymentSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                paymenttWaysSaleDialog.dismiss();
            }
        });
    }

    //selecionar button cancelar
    public void activateCancelDialog() {
        btCancelar = findViewById(R.id.btCancelar);
        final Dialog cancelSaleDialog = new Dialog(MainActivity.this);
        cancelSaleDialog.setContentView(R.layout.give_up);
        cancelSaleDialog.setCancelable(false);

        btCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!prod_Controller.getCart().getItens().isEmpty())
                    cancelSaleDialog.show();
            }
        });

        btDismissCancelSale = cancelSaleDialog.findViewById(R.id.giveup_cancel_bt);
        btDismissCancelSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelSaleDialog.dismiss();
            }
        });

        btConfirmCancelSale = cancelSaleDialog.findViewById(R.id.giveup_confirm_bt);
        btConfirmCancelSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prod_Controller.clearCart();
                cancelSaleDialog.dismiss();
            }
        });
    }

    //resumo da compra
    public void activateResumoDialog() {
        btResumoConfirmar = paymenttWaysSaleDialog.findViewById(R.id.pm_confirm_payment_bt);
        final Dialog ResumoSaleDialog = new Dialog(this);
        final Dialog insertCard = new Dialog(this);
        insertCard.setCancelable(false);
        removeCard = new Dialog(this);
        removeCard.setCancelable(false);
        insertCard.setContentView(R.layout.insert_card);
        removeCard.setContentView(R.layout.remove_card);
        ResumoSaleDialog.setContentView(R.layout.resumo_compra);
        ResumoSaleDialog.setCancelable(false);

        btResumoConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                paymenttWaysSaleDialog.dismiss();
                Cart cart = prod_Controller.getCart();
                TextView rc_total = ResumoSaleDialog.findViewById(R.id.rc_tvPreco);
                TableLayout table = ResumoSaleDialog.findViewById(R.id.rc_TableItens);
                table.removeAllViews();
                for (ItemVenda item : cart.getItens()) {
                    LinearLayout row = (LinearLayout) mInflater.inflate(R.layout.resumocomprarow, null);
                    TextView tvEdit = row.findViewById(R.id.tvQuantidade);
                    tvEdit.setText(String.valueOf(item.getQuantity()));
                    tvEdit = row.findViewById(R.id.tvItemName);
                    tvEdit.setText(item.getName());
                    tvEdit = row.findViewById(R.id.tvItemTotal);
                    tvEdit.setText(NumberFormat.getCurrencyInstance().format((item.getPrice() * item.getQuantity())));
                    table.addView(row);
                }
                rc_total.setText(NumberFormat.getCurrencyInstance().format(cart.getTotal()));

                TextView tv = ResumoSaleDialog.findViewById(R.id.txtTipoPagamento);
                tv.setText(paymentType);
                ImageView img = ResumoSaleDialog.findViewById(R.id.imageViewTipoDePag);
                if (paymentType.equals("débito"))
                    img.setImageDrawable(getDrawable(R.drawable.debito));
                else img.setImageDrawable(getDrawable(R.drawable.credito));
                ResumoSaleDialog.show();
            }
        });

        btDismissResumoSale = ResumoSaleDialog.findViewById(R.id.btn_Resumo_Cancelar);
        btDismissResumoSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ResumoSaleDialog.dismiss();
            }
        });

        btConfirmResumoSale = ResumoSaleDialog.findViewById(R.id.btn_Resumo_Confirmar);
        btConfirmResumoSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertCard.show();
                //insertCDS.show();
                new android.os.Handler().postDelayed(
                        new Runnable() {
                            public void run() {
                                insertCard.dismiss();
                                insertCVV();
                            }
                        },
                        3000);
                ResumoSaleDialog.dismiss();
            }
        });
    }

    public void insertCVV() {
        insertCDS.show();
        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        final EditText pass = insertCDS.findViewById(R.id.editText_cds_pass);
                        final Button btOK = insertCDS.findViewById(R.id.bt_cds_ok);
                        btOK.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                insertCDS.dismiss();
                                prod_Controller.requestPayment(String.valueOf(pass.getText()));
                                pass.setText("");
                            }
                        });

                        pass.setOnEditorActionListener(new EditText.OnEditorActionListener() {
                            @Override
                            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                                if (actionId == EditorInfo.IME_ACTION_DONE) {
                                    btOK.performClick();
                                    return true;
                                }
                                return false;
                            }
                        });
                    }
                },
                3000);

        final Button cancelCvv = insertCDS.findViewById(R.id.bt_cds_cancel);
        cancelCvv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertCDS.dismiss();
            }
        });
    }

    public void pagamentoEfetuado() {
        makeText(this, "Pagamento realizado com sucesso !.", LENGTH_LONG).show();
        removeCard.show();
        LLCategories.getChildAt(0).callOnClick();
        final Handler someHandler = new Handler(getMainLooper());
        someHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                removeCard.dismiss();
                //send_email.show();
                activateImprimirDialog();
            }
        }, 4000);
    }

    public void pagamentoRecusado() {
        makeText(this, "Pagamento recusado.", LENGTH_LONG).show();
        removeCard.show();
        final Handler someHandler = new Handler(getMainLooper());
        someHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                removeCard.dismiss();
            }
        }, 4000);
    }

    //selecionar Imprimir
    public void activateImprimirDialog() {
        send_email.show();

        final ImageView sendEnviar = send_email.findViewById(R.id.img_Enviar);

        final ImageView sendImprimir = send_email.findViewById(R.id.img_Imprimir);
        ((LinearLayout) sendImprimir.getParent()).setBackground(getDrawable(R.drawable.selected_payment_way));

        sendImprimir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendType = "imprimir";
                ((LinearLayout) view.getParent()).setBackground(getDrawable(R.drawable.selected_payment_way));
                ((LinearLayout) sendEnviar.getParent()).setBackgroundResource(0);
                LUtil.choosePrinter(prod_Controller.getCart().getItens(), ProductController.NFCe_SERVER_URL);
                thanks.show();
                prod_Controller.clearCart();
                new android.os.Handler().postDelayed(
                        new Runnable() {
                            public void run() {
                                thanks.dismiss();
                            }
                        },
                        5000);
                send_email.dismiss();
            }
        });
    }
}
