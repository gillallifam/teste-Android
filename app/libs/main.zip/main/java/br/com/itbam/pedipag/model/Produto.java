package br.com.itbam.pedipag.model;

import android.widget.ImageView;

public class Produto {


    private int id;
    private String nome;
    private double preco;
    private int quantidade;
    String tipo;
    String categoria;
    private ImageView img;

    public Produto() {

    }

    public Produto(String nome, double preco, String tipo, String categoria, ImageView img) {
        this.nome = nome;
        this.preco = preco;
        this.img = img;
        this.tipo = tipo;
        this.categoria = categoria;
    }

/*    @Override
    public String toString() {
        return this.nome + "-" + this.tipo + "-" + this.categoria;
    }*/

    /*public Produto(String nome, double preco, int quantidade) {
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
    }*/

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public ImageView getImg() {
        return img;
    }

    public void setImg(ImageView img) {
        this.img = img;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}
