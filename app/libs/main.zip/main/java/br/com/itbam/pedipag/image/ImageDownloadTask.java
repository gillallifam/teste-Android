package br.com.itbam.pedipag.image;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import br.com.itbam.pedipag.controller.ProductController;


class ImageDownloadTask extends AsyncTask<BatchImageDownloadSender, Void, BatchImageDownloadReceiver> {

    private static final String ERROR_TAG = "DOWNLOAD IMAGE ERROR: ";

    private BatchImageDownloadSender mSender;

    @Override
    protected BatchImageDownloadReceiver doInBackground(BatchImageDownloadSender... batchImageDownloadSenders) {

        mSender = batchImageDownloadSenders[0];

        if (mSender.mURL == null || mSender.mURL.isEmpty() || mSender.mURL.equalsIgnoreCase("Null")) {
            return null;
        }

        URL url = null;


        try {

            if (mSender.mType == ImageDowloadService.DownloadType.Product) {
                String nurl = ProductController.PRODUCT_IMAGE_SERVER_URL + mSender.mURL.replaceAll(" ", "%20");
                //System.out.println("**********************" + nurl);
                url = new URL(nurl);
            } else {
                url = new URL("http://" + mSender.mURL);
            }

        } catch (MalformedURLException e) {
            Log.e(ERROR_TAG, e.getMessage());
        }
        //System.out.println("$$$$$" + mSender.mContext.getExternalFilesDir("pedpag/" + mSender.mId));
        File path = mSender.mContext.getExternalFilesDir("pedpag/" + mSender.mId);

        if (!path.exists()) {
            path.mkdirs();
        }

        File imageFile = new File(path, mSender.mId + ".png");
//        if(imageFile.exists())
//        {
//            return new BatchImageDownloadReceiver(mSender.mId, BitmapFactory.decodeFile(imageFile.getAbsolutePath()));
//        }

        Bitmap bitmap = null;
        try {

            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setDoOutput(false);
            httpURLConnection.connect();

            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream in = httpURLConnection.getInputStream();
                bitmap = BitmapFactory.decodeStream(in);
                //System.out.println("BITMAP>" + bitmap);
                in.close();
            } else {
                throw new ConnectException("Sem conexão com o servidor.");
            }

        } catch (Exception e) {
            Log.e(ERROR_TAG, e.getMessage());
            return null;
        }

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(imageFile);
        } catch (FileNotFoundException e) {
            Log.e(ERROR_TAG, e.getMessage());
        }

        try {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            out.close();

            MediaScannerConnection.scanFile(mSender.mContext, new String[]{imageFile.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {

                }
            });
        } catch (IOException | RuntimeException e) {
            Log.e(ERROR_TAG, e.getMessage());
        }

        return new BatchImageDownloadReceiver(mSender.mId, bitmap, imageFile.getAbsolutePath());
    }

    @Override
    protected void onPostExecute(BatchImageDownloadReceiver receiver) {
        mSender.mReceiver.DownloadFinished(receiver);
    }
}
