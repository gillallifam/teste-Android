package br.com.itbam.pedipag.model;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import br.com.itbam.pedipag.R;

public class Cart {
    private Context context;
    double total;
    private ArrayList<ItemVenda> itens;
    private LinearLayout LLItensInCart;
    private TextView tvTotal;
    SharedPreferences appSharedPrefs;
    SharedPreferences.Editor prefsEditor;

    public Cart(Context ctx) {
        Activity act = (Activity) ctx;
        this.context = ctx;
        itens = new ArrayList<>();
        this.LLItensInCart = act.findViewById(R.id.LLItensInCart);
        this.tvTotal = ((Activity) context).findViewById(R.id.tvValorTotal);
        this.appSharedPrefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        this.prefsEditor = appSharedPrefs.edit();
    }

    public double getTotal() {
        return this.total;
    }

    public int getProductQuantity(int id) {
        for (ItemVenda item : itens) {
            if (item.getId() == id) return item.getQuantity();
        }
        return 0;
    }

    public void removeCartProduct(ItemVenda toRemoveProduct) {
        this.itens.remove(toRemoveProduct);
    }

    private int itemIsInCart(int id) {
        for (ItemVenda item : itens) {
            if (item.getId() == id) {
                return itens.indexOf(item);
            }
        }
        return -1;
    }

    public double sumTotal(double value) {
        this.total += value;
        this.tvTotal.setText(NumberFormat.getCurrencyInstance().format(this.total));
        //this.tvTotal.setText(String.format("%.2f", this.total));
        return this.total;
    }

    public void addProductItem(ItemVenda cartProduct) {
        this.itens.add(0, cartProduct);
    }

    public void incrementCartProductQuantity(int productId) {
        for (ItemVenda itemVenda : this.itens) {
            if (itemVenda.getId() == productId) {
                //System.out.println(itemVenda.getQuantity() + "-" + getProductQuantity(productId));
//                if (itemVenda.getQuantity() < getProductQuantity(productId)) {
//
//                }

                itemVenda.setQuantity(itemVenda.getQuantity() + 1);
                //your_scrollview.scrollTo(0, your_EditBox.getBottom());
            }
        }
    }

    public int decrementCartProductQuantity(int productId) {
        for (ItemVenda cartProduct : this.itens) {
            if (cartProduct.getId() == productId) {
                if (cartProduct.getQuantity() - 1 == 0) {
                    return 1;
                } else {
                    cartProduct.setQuantity(cartProduct.getQuantity() - 1);
                    return 0;
                }
            }
        }
        return 0;
    }


    public ArrayList<ItemVenda> getItens() {
        return itens;
    }

    public ItemVenda getCartProductById(int productId) {
        for (ItemVenda cartProduct : this.itens) {
            if (cartProduct.getId() == productId) {
                return cartProduct;
            }
        }
        return new ItemVenda();
    }

    public void loadCartFromPrefs() {

    }

    public void saveCartToPrefs() {
        Gson gson = new Gson();
        String json = gson.toJson(itens);
        System.out.println(json);
        prefsEditor.putString(String.valueOf(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis())), json);
        prefsEditor.commit();

        //String back = appSharedPrefs.getString("XXXX", "");
        //System.out.println(back);

        /*Type type = new TypeToken<ArrayList<ItemVenda>>() {
        }.getType();
        ArrayList<ItemVenda> backItens = gson.fromJson(back, type);
        System.out.println(backItens);*/

        Map<String, ?> keys = appSharedPrefs.getAll();

        for (Map.Entry<String, ?> entry : keys.entrySet()) {
            Log.d("map values", entry.getKey() + ": " + entry.getValue().toString());
        }
        //Student mStudentObject = gson.fromJson(json, ItemVenda.class);

    }
//    public void addProduct(Product prod) {
//        ((HorizontalScrollView) LLItensInCart.getParent()).fullScroll(HorizontalScrollView.FOCUS_LEFT);
//        int index = itemIsInCart(prod.getId());
//        if (index >= 0)
//        {
//            itens.get(index).increment();
//            LinearLayout LLItem = ((Activity) context).findViewById(prod.getId());
//
//            //IF PRODUCTS EXISTS - BRING IT TO BE THE FIRST ONE
//            if (LLItensInCart.getChildAt(0) != LLItem) {
//                LLItensInCart.removeView(LLItem);
//                LLItensInCart.addView(LLItem, 0);
//            }
//        }
//        else
//        {
//            ItemVenda iv = new ItemVenda(prod.getId(), prod.getName(), prod.getPrice());
//            iv.setId(prod.getId());
//            itens.add(iv);
//
//            LinearLayout LLItem = new LinearLayout(context);
//            LLItem.setOrientation(LinearLayout.VERTICAL);
//            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
//                    ViewGroup.LayoutParams.WRAP_CONTENT,
//                    ViewGroup.LayoutParams.WRAP_CONTENT
//            );
//
//            LLItem.setLayoutParams(params);
//            LLItem.setId(prod.getId());
//
//            ImageView productImage = new ImageView(context);
//            productImage.setImageResource(R.drawable.hai1);
//            productImage.setId(prod.getId());
//
//            TextView prodQuant = new TextView(context);
//            prodQuant.setText("XXXXXX");
//
//            LLItem.addView(productImage);
//            LLItem.addView(prodQuant);
//            LLItensInCart.addView(LLItem, 0);
//        }
//
//        tvTotal.setText(NumberFormat.getCurrencyInstance().format(sumTotalInCart()));
//    }

//    public int remProduct(int id) {
//        for (ItemVenda item : itens) {
//            if (item.getId() == id) {
//                if (item.getQuantity() > 1) {
//                    item.decrement();
//
//                    return item.getQuantity();
//                } else {
//                    itens.remove(item);
//
//                    return 0;
//                }
//            }
//        }
//
//        return -1;
//    }

//    public void append(LinearLayout cartProductLayout){
//        LLItensInCart.addView(cartProductLayout, 0);
//    }

    //    private double sumTotalInCart() {
//        double total = 0;
//        for (ItemVenda iv : itens) {
//            total += iv.getPrice() * iv.getQuantity();
//        }
//        return total;
//    }
//
    public void clear() {
        LLItensInCart.removeAllViews();
        itens.clear();
        total = 0;
        tvTotal.setText(NumberFormat.getCurrencyInstance().format(0));

        //tvTotal.setText("R$0,00");
    }
}
