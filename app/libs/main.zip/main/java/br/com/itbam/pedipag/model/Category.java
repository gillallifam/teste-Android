package br.com.itbam.pedipag.model;

public class Category {

    String[] list = new String[]{};

    public Category(){ }

    public String[] getList() {
        return list;
    }
    public void setList(String[] list) {
        this.list = list;
    }
}
