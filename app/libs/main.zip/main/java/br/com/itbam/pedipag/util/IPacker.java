package br.com.itbam.pedipag.util;

/**
 * packer interface
 * 
 */
public interface IPacker {

    /**
     * get APDU interface
     * 
     * @return APDU interface
     */
    public IApdu getApdu();

}
