package br.com.itbam.pedipag.util;

import android.util.Log;

import com.pax.dal.IDAL;

import br.com.itbam.pedipag.view.MainActivity;

public class GetObj {

    private static IDAL dal;
    public static String logStr = "";

    // 获取IDal dal对象
    public static IDAL getDal() {
        dal = MainActivity.idal;
        if (dal == null) {
            Log.e("NeptuneLiteDemo", "dal is null");
        }
        return dal;
    }

}
