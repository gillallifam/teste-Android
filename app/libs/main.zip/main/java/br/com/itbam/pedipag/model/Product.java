package br.com.itbam.pedipag.model;

public class Product {
    private String name, category, subCategory, variation;
    private double price;
    private int id, quantity, numVendas;
    private String imagePath;

    private String mLocalImagePath;

    public Product(int id, String name, String category, String subCategory, double price, int quantity, String img) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.subCategory = subCategory;
        this.price = price;
        this.quantity = quantity;
        this.imagePath = img;
    }

    public String getLocalImagePath() {

        if(mLocalImagePath == null  || mLocalImagePath.isEmpty() || mLocalImagePath.equalsIgnoreCase("null")){
            return "";
        }

        return mLocalImagePath;
    }

    public void setLocalImagePath(String mLocalImagePath) {
        this.mLocalImagePath = mLocalImagePath;
    }

    public Product() { }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }
    public String getSubCategory() {
        return subCategory;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImage() {
        return imagePath;
    }
    public void setImage(String image) {
        this.imagePath = image;
    }
}
