package br.com.itbam.pedipag.image;


public interface IImageDownloadReceiver
{
    void DownloadFinished(BatchImageDownloadReceiver receiver);
}
